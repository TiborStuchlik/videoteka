Ext.define('KitchenSink.view.ContentPanel', {
    extend: 'Ext.panel.Panel',
    xtype: 'contentPanel',
    id: 'content-panel',
    title: '&nbsp;',

    autoScroll: true
});