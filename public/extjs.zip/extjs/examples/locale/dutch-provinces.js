// some data used in the examples
Ext.namespace('Ext.exampledata');

Ext.exampledata.dutch_provinces = [
	['Drenthe'],
	['Flevoland'],
	['Friesland'],
	['Gelderland'],
	['Groningen'],
	['Limburg'],
	['Noord-Brabant'],
	['Noord-Holland'],
	['Overijsel'],
	['Utrecht'],
	['Zeeland'],
	['Zuid-Holland']
    ];
